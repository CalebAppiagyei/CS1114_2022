import student.TestCase;
import static org.assertj.core.api.Assertions.*;

// -------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your test class here.
 *  Summarize what your test objectives are.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class BrickTest
    extends TestCase
{
    //~ Fields ................................................................

    Brick brick;


    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new BrickTest test object.
     */
    public BrickTest()
    {
        // The constructor is usually empty in unit tests, since it runs
        // once for the whole class, not once for each test method.
        // Per-test initialization should be placed in setUp() instead.
    }


    //~ Methods ...............................................................

    // ----------------------------------------------------------
    /**
     * Sets up the test fixture.
     * Called before every test case method.
     */
    public void setUp()
    {
        /*# Pick your own values instead of those used below */
        brick = new Brick(0, 0, 0);
    }


    // ----------------------------------------------------------
    /**
     * Test the basic accessors on a brand new Brick.
     */
    public void testBrickConstructor()
    {
        /*# Put your own assertions in here. */
    }

}
