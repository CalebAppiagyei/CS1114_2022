import student.TestCase;
import static org.assertj.core.api.Assertions.*;

// -------------------------------------------------------------------------
/**
 *  Write a one-sentence summary of your test class here.
 *  Summarize what your test objectives are.
 *
 *  @author your name (your-pid)
 *  @version (place the date here, in this format: yyyy.mm.dd)
 */
public class PalletTest
    extends TestCase
{
    //~ Fields ................................................................

    Pallet pallet;


    //~ Constructor ...........................................................

    // ----------------------------------------------------------
    /**
     * Creates a new PalletTest test object.
     */
    public PalletTest()
    {
        // The constructor is usually empty in unit tests, since it runs
        // once for the whole class, not once for each test method.
        // Per-test initialization should be placed in setUp() instead.
    }


    //~ Methods ...............................................................

    // ----------------------------------------------------------
    /**
     * Sets up the test fixture.
     * Called before every test case method.
     */
    public void setUp()
    {
        /*# Pick your own values instead of those used below */
        pallet = new Pallet(1, 1);
    }


    // ----------------------------------------------------------
    /**
     * Test the basic accessors on a brand new Pallet.
     */
    public void testPalletConstructor()
    {
        /*# Put your own assertions in here. */
    }

}
